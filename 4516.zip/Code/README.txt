The sample code is built using November 2009 CTP version of Windows Azure SDK and .NET Services SDK. 
Tools used were Visual Studio.NET 2008 and SQL Server 2008 Express
Some examples may require you to be proficient in X.509 certificates. So, please make sure you understand X.509 certificate processing in .NET, WCF and Windows Azure.
When starting Visual Studio .NET, start as administrator and then open the solution using File > Open Solution
