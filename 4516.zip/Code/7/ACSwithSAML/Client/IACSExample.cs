﻿namespace ProAzure.MachineInfo.Service
{
    using System;
    using System.Collections.Generic;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;

    [ServiceContract]
    public interface IACSExample
    {
        [OperationContract]
        [WebGet(UriTemplate = "getmachinename")]
        string GetMachineName();

        [OperationContract]
        [WebGet(UriTemplate = "getuserdomainname")]
        string GetUserDomainName();

        [OperationContract]
        [WebGet(UriTemplate = "getosversion")]
        string GetOSVersion();

        
        [OperationContract]
        [WebGet(UriTemplate = "encodestring?data={data}")]
        byte[] EncodeString(string data);

       

    }
}
