Open .\SignedTokenRequests\Chapter7Solution.sln to open the source code for this chapter

Prerequisites:
---------------
1. Windows Identity Foundation and Windows Identity Foundation SDK 

http://www.microsoft.com/downloads/details.aspx?familyid=C148B2DF-C7AF-46BB-9162-2C9422208504&displaylang=en,
http://www.microsoft.com/downloads/details.aspx?FamilyID=eb9c345f-e830-40b8-a5fe-ae7a864c4d76&displaylang=en

2. Developer Identity Training Kit
http://www.microsoft.com/downloads/details.aspx?familyid=C3E315FA-94E2-4028-99CB-904369F177C0&displaylang=en