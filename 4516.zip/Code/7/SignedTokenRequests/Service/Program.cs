﻿
namespace ProAzure.MachineInfo.Service
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;
    using Microsoft.AccessControl.SDK.ACSCalculator.AuthorizationManager;

    /*
  Client issuer key: iEVAlclelnAsLoF4mn61PGH/xo1DR8l7F6bOAu6Pb1o=
Client issuer name: acsexample
Service Token Policy key: 8O++r46Eo6e6VhGQaHSCfINhYMMCu14xsAectW2EFfk=
    * */
    class Program
    {
        const string serviceNamespace = "proazure-1";
        const string trustedTokenPolicyKey = "8O++r46Eo6e6VhGQaHSCfINhYMMCu14xsAectW2EFfk=";

        const string acsHostName = "accesscontrol.windows.net";
        const string trustedAudience = "http://localhost/acsexample";
        const string requiredClaimType = "action";

        static void Main()
        {
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.None);

            Uri address = new Uri(trustedAudience);

            WebServiceHost host = new WebServiceHost(typeof(ACSExample));
            host.AddServiceEndpoint(typeof(IACSExample), binding, address);

            host.Authorization.ServiceAuthorizationManager = new ACSAuthorizationManager(
                acsHostName,
                serviceNamespace,
                trustedAudience,
                Convert.FromBase64String(trustedTokenPolicyKey),
                requiredClaimType);

            host.Open();

            Console.WriteLine("The ACSExample Service is listening");
            Console.WriteLine("Press <ENTER> to exit");
            Console.ReadLine();

            host.Close();
        }
    }
}
