﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.IdentityModel.Claims;
using System.Threading;


namespace ACS_WebRole
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IClaimsPrincipal icp = Thread.CurrentPrincipal as IClaimsPrincipal;
            IClaimsIdentity ici = icp.Identity as IClaimsIdentity;
            Response.Write("Welcome to Fabrikamair <br/><br/>:Claims:<br/>");
            foreach (Claim c in ici.Claims)
                Response.Write(c.ClaimType + "-" + c.Value + "<br/>");

        }
    }
}
