﻿namespace ServiceManagement
{
    partial class ServiceManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServiceManagementForm));
            this.txtLog = new System.Windows.Forms.TextBox();
            this.btnLoadCert = new System.Windows.Forms.Button();
            this.lstOperations = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.txtOpId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDomainNumber = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ddlMode = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.ddlDeploymentStatus = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtStagingDeploymentName = new System.Windows.Forms.TextBox();
            this.btnBrowseConfigFile = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtConfigFilePath = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPackageUri = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDeploymentLabel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDeploymentName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ddlSlotType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ddlKeyType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ddlResourceType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtResourceName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBrowseCertificate = new System.Windows.Forms.Button();
            this.txtCertificatePath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSubscriptionId = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.AcceptsReturn = true;
            this.txtLog.BackColor = System.Drawing.SystemColors.MenuText;
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtLog.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLog.ForeColor = System.Drawing.Color.Yellow;
            this.txtLog.Location = new System.Drawing.Point(0, 497);
            this.txtLog.Margin = new System.Windows.Forms.Padding(4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(953, 293);
            this.txtLog.TabIndex = 0;
            this.txtLog.Text = "---------------------Output Window--------------------------";
            // 
            // btnLoadCert
            // 
            this.btnLoadCert.Location = new System.Drawing.Point(474, 56);
            this.btnLoadCert.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoadCert.Name = "btnLoadCert";
            this.btnLoadCert.Size = new System.Drawing.Size(116, 23);
            this.btnLoadCert.TabIndex = 1;
            this.btnLoadCert.Text = "Load Certificate";
            this.btnLoadCert.UseVisualStyleBackColor = true;
            this.btnLoadCert.Click += new System.EventHandler(this.btnLoadCert_Click);
            // 
            // lstOperations
            // 
            this.lstOperations.BackColor = System.Drawing.Color.White;
            this.lstOperations.Dock = System.Windows.Forms.DockStyle.Left;
            this.lstOperations.ForeColor = System.Drawing.Color.Brown;
            this.lstOperations.FormattingEnabled = true;
            this.lstOperations.ItemHeight = 16;
            this.lstOperations.Items.AddRange(new object[] {
            "--Service Management Operations--",
            "List Affinity Groups",
            "Get Affinity Group",
            "List Storage Services",
            "Get Storage Service",
            "Get Storage Keys",
            "Regenerate Keys",
            "List Hosted Services",
            "Get Hosted Service",
            "Get Operation Status",
            "Get Deployment",
            "Create Deployment",
            "Swap Deployment",
            "Delete Deployment",
            "Update Deployment Status",
            "Change Deployment Config"});
            this.lstOperations.Location = new System.Drawing.Point(0, 0);
            this.lstOperations.Margin = new System.Windows.Forms.Padding(4);
            this.lstOperations.Name = "lstOperations";
            this.lstOperations.Size = new System.Drawing.Size(353, 484);
            this.lstOperations.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.btnExecute);
            this.groupBox1.Controls.Add(this.txtOpId);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtDomainNumber);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.ddlMode);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.ddlDeploymentStatus);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtStagingDeploymentName);
            this.groupBox1.Controls.Add(this.btnBrowseConfigFile);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtConfigFilePath);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtPackageUri);
            this.groupBox1.Controls.Add(this.btnLoadCert);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtDeploymentLabel);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtDeploymentName);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.ddlSlotType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.ddlKeyType);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.ddlResourceType);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtResourceName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnBrowseCertificate);
            this.groupBox1.Controls.Add(this.txtCertificatePath);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtSubscriptionId);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(353, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(600, 496);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Account Information";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(339, 455);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(107, 27);
            this.btnClear.TabIndex = 34;
            this.btnClear.Text = "Clear Output";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(171, 455);
            this.btnExecute.Margin = new System.Windows.Forms.Padding(4);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(147, 28);
            this.btnExecute.TabIndex = 33;
            this.btnExecute.Text = "Execute Operation";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // txtOpId
            // 
            this.txtOpId.BackColor = System.Drawing.SystemColors.Window;
            this.txtOpId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpId.Location = new System.Drawing.Point(171, 424);
            this.txtOpId.Margin = new System.Windows.Forms.Padding(4);
            this.txtOpId.Name = "txtOpId";
            this.txtOpId.Size = new System.Drawing.Size(207, 23);
            this.txtOpId.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 424);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "OP-ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 393);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(110, 17);
            this.label15.TabIndex = 32;
            this.label15.Text = "Domain Number";
            // 
            // txtDomainNumber
            // 
            this.txtDomainNumber.BackColor = System.Drawing.SystemColors.Window;
            this.txtDomainNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDomainNumber.Location = new System.Drawing.Point(171, 393);
            this.txtDomainNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtDomainNumber.Name = "txtDomainNumber";
            this.txtDomainNumber.Size = new System.Drawing.Size(207, 23);
            this.txtDomainNumber.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 362);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 17);
            this.label14.TabIndex = 31;
            this.label14.Text = "Upgrade Mode";
            // 
            // ddlMode
            // 
            this.ddlMode.BackColor = System.Drawing.SystemColors.Window;
            this.ddlMode.FormattingEnabled = true;
            this.ddlMode.Items.AddRange(new object[] {
            "auto",
            "manual"});
            this.ddlMode.Location = new System.Drawing.Point(171, 362);
            this.ddlMode.Name = "ddlMode";
            this.ddlMode.Size = new System.Drawing.Size(207, 24);
            this.ddlMode.TabIndex = 30;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 332);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 17);
            this.label13.TabIndex = 29;
            this.label13.Text = "Deployment Status";
            // 
            // ddlDeploymentStatus
            // 
            this.ddlDeploymentStatus.BackColor = System.Drawing.SystemColors.Window;
            this.ddlDeploymentStatus.FormattingEnabled = true;
            this.ddlDeploymentStatus.Items.AddRange(new object[] {
            "running",
            "suspended"});
            this.ddlDeploymentStatus.Location = new System.Drawing.Point(171, 332);
            this.ddlDeploymentStatus.Name = "ddlDeploymentStatus";
            this.ddlDeploymentStatus.Size = new System.Drawing.Size(207, 24);
            this.ddlDeploymentStatus.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(382, 188);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(176, 17);
            this.label12.TabIndex = 27;
            this.label12.Text = "Staging Deployment Name";
            // 
            // txtStagingDeploymentName
            // 
            this.txtStagingDeploymentName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStagingDeploymentName.Location = new System.Drawing.Point(385, 209);
            this.txtStagingDeploymentName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStagingDeploymentName.Name = "txtStagingDeploymentName";
            this.txtStagingDeploymentName.Size = new System.Drawing.Size(207, 23);
            this.txtStagingDeploymentName.TabIndex = 26;
            // 
            // btnBrowseConfigFile
            // 
            this.btnBrowseConfigFile.Location = new System.Drawing.Point(385, 302);
            this.btnBrowseConfigFile.Name = "btnBrowseConfigFile";
            this.btnBrowseConfigFile.Size = new System.Drawing.Size(94, 23);
            this.btnBrowseConfigFile.TabIndex = 25;
            this.btnBrowseConfigFile.Text = "Browse...";
            this.btnBrowseConfigFile.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 302);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(145, 17);
            this.label11.TabIndex = 24;
            this.label11.Text = "Local Config File Path";
            // 
            // txtConfigFilePath
            // 
            this.txtConfigFilePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConfigFilePath.Location = new System.Drawing.Point(171, 302);
            this.txtConfigFilePath.Margin = new System.Windows.Forms.Padding(4);
            this.txtConfigFilePath.Name = "txtConfigFilePath";
            this.txtConfigFilePath.Size = new System.Drawing.Size(207, 23);
            this.txtConfigFilePath.TabIndex = 23;
            this.txtConfigFilePath.Text = "C:\\Tejaswi\\3PLogic\\3PLogicAzure\\SilverliningWebService\\bin\\Debug\\Publish\\ServiceC" +
                "onfiguration.cscfg";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 271);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 17);
            this.label10.TabIndex = 22;
            this.label10.Text = "Package Blob Url";
            // 
            // txtPackageUri
            // 
            this.txtPackageUri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPackageUri.Location = new System.Drawing.Point(171, 271);
            this.txtPackageUri.Margin = new System.Windows.Forms.Padding(4);
            this.txtPackageUri.Name = "txtPackageUri";
            this.txtPackageUri.Size = new System.Drawing.Size(406, 23);
            this.txtPackageUri.TabIndex = 21;
            this.txtPackageUri.Text = "http://proazurestorage.blob.core.windows.net/silverliningpackages/SilverliningWeb" +
                "Service.cspkg";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 240);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "Deployment Label";
            // 
            // txtDeploymentLabel
            // 
            this.txtDeploymentLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDeploymentLabel.Location = new System.Drawing.Point(171, 240);
            this.txtDeploymentLabel.Margin = new System.Windows.Forms.Padding(4);
            this.txtDeploymentLabel.Name = "txtDeploymentLabel";
            this.txtDeploymentLabel.Size = new System.Drawing.Size(207, 23);
            this.txtDeploymentLabel.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 209);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "Deployment Name";
            // 
            // txtDeploymentName
            // 
            this.txtDeploymentName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDeploymentName.Location = new System.Drawing.Point(171, 209);
            this.txtDeploymentName.Margin = new System.Windows.Forms.Padding(4);
            this.txtDeploymentName.Name = "txtDeploymentName";
            this.txtDeploymentName.Size = new System.Drawing.Size(207, 23);
            this.txtDeploymentName.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 178);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 16;
            this.label7.Text = "Slot Type";
            // 
            // ddlSlotType
            // 
            this.ddlSlotType.BackColor = System.Drawing.Color.White;
            this.ddlSlotType.FormattingEnabled = true;
            this.ddlSlotType.Items.AddRange(new object[] {
            "staging",
            "production"});
            this.ddlSlotType.Location = new System.Drawing.Point(171, 178);
            this.ddlSlotType.Name = "ddlSlotType";
            this.ddlSlotType.Size = new System.Drawing.Size(207, 24);
            this.ddlSlotType.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 148);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Key Type";
            // 
            // ddlKeyType
            // 
            this.ddlKeyType.BackColor = System.Drawing.SystemColors.Window;
            this.ddlKeyType.FormattingEnabled = true;
            this.ddlKeyType.Items.AddRange(new object[] {
            "primary",
            "secondary"});
            this.ddlKeyType.Location = new System.Drawing.Point(171, 148);
            this.ddlKeyType.Name = "ddlKeyType";
            this.ddlKeyType.Size = new System.Drawing.Size(207, 24);
            this.ddlKeyType.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Resource Name";
            // 
            // ddlResourceType
            // 
            this.ddlResourceType.BackColor = System.Drawing.SystemColors.Window;
            this.ddlResourceType.FormattingEnabled = true;
            this.ddlResourceType.Items.AddRange(new object[] {
            "Hosted Service Name",
            "Storage Account Name",
            "Affinity Group Name"});
            this.ddlResourceType.Location = new System.Drawing.Point(171, 87);
            this.ddlResourceType.Name = "ddlResourceType";
            this.ddlResourceType.Size = new System.Drawing.Size(207, 24);
            this.ddlResourceType.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Resource Type";
            // 
            // txtResourceName
            // 
            this.txtResourceName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtResourceName.Location = new System.Drawing.Point(171, 118);
            this.txtResourceName.Margin = new System.Windows.Forms.Padding(4);
            this.txtResourceName.Name = "txtResourceName";
            this.txtResourceName.Size = new System.Drawing.Size(207, 23);
            this.txtResourceName.TabIndex = 5;
            this.txtResourceName.Text = "proazure";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 55);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Certificate Path";
            // 
            // btnBrowseCertificate
            // 
            this.btnBrowseCertificate.Location = new System.Drawing.Point(385, 56);
            this.btnBrowseCertificate.Name = "btnBrowseCertificate";
            this.btnBrowseCertificate.Size = new System.Drawing.Size(82, 23);
            this.btnBrowseCertificate.TabIndex = 3;
            this.btnBrowseCertificate.Text = "Browse...";
            this.btnBrowseCertificate.UseVisualStyleBackColor = true;
            // 
            // txtCertificatePath
            // 
            this.txtCertificatePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCertificatePath.Location = new System.Drawing.Point(171, 56);
            this.txtCertificatePath.Margin = new System.Windows.Forms.Padding(4);
            this.txtCertificatePath.Name = "txtCertificatePath";
            this.txtCertificatePath.Size = new System.Drawing.Size(207, 23);
            this.txtCertificatePath.TabIndex = 2;
            this.txtCertificatePath.Text = "proazureservicemgmt.cer";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "SubscriptionId";
            // 
            // txtSubscriptionId
            // 
            this.txtSubscriptionId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSubscriptionId.Location = new System.Drawing.Point(171, 25);
            this.txtSubscriptionId.Margin = new System.Windows.Forms.Padding(4);
            this.txtSubscriptionId.Name = "txtSubscriptionId";
            this.txtSubscriptionId.Size = new System.Drawing.Size(207, 23);
            this.txtSubscriptionId.TabIndex = 0;
            this.txtSubscriptionId.Text = "8C0277D9-EB3A-4F72-8199-2367A9C00E6D";
            this.txtSubscriptionId.UseSystemPasswordChar = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // ServiceManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(953, 790);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lstOperations);
            this.Controls.Add(this.txtLog);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ServiceManagementForm";
            this.Text = "Service Management API";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Button btnLoadCert;
        private System.Windows.Forms.ListBox lstOperations;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSubscriptionId;
        private System.Windows.Forms.TextBox txtCertificatePath;
        private System.Windows.Forms.Button btnBrowseCertificate;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtResourceName;
        private System.Windows.Forms.ComboBox ddlResourceType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOpId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ddlKeyType;
        private System.Windows.Forms.ComboBox ddlSlotType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDeploymentName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDeploymentLabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPackageUri;
        private System.Windows.Forms.Button btnBrowseConfigFile;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtConfigFilePath;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtStagingDeploymentName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox ddlDeploymentStatus;
        private System.Windows.Forms.TextBox txtDomainNumber;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ddlMode;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnClear;
    }
}

