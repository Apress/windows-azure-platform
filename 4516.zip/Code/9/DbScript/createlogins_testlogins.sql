CREATE LOGIN testlogin1 WITH PASSWORD='pass@word1';

CREATE LOGIN testlogin2 WITH PASSWORD='pass@word1';

CREATE LOGIN testlogin3 WITH PASSWORD='pass@word1';
