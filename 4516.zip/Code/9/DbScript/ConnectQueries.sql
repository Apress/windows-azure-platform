select * from sys.databases;
select @@version;
select @@language;
