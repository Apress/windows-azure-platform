﻿namespace ProAzureCommonLib {
    
    
    public partial class SystemMessageExchange {
        partial class SystemInfoDataTable
        {
        }
    }
}
